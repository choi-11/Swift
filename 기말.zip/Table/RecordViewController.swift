//
//  RecordViewController.swift
//  Table
//
//  Created by Mina Choi on 2022/06/11.
//

import UIKit
import AVFoundation

class RecordViewController: UIViewController, AVAudioPlayerDelegate, AVAudioRecorderDelegate {
    
    var audioPlayer: AVAudioPlayer?
    var audioRecorder: AVAudioRecorder?
    
    @IBOutlet var playButton: UIButton!
    @IBOutlet var stopButton: UIButton!
    
    @IBOutlet var recordButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        playButton.isEnabled = false
                stopButton.isEnabled = false
                // 도큐먼트 디렉터리 확인
                let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
                let docsDir = dirPaths[0] as String
                // sound.caf 이름의 파일을 위한 URL 구성
                let soundFilePath = docsDir.appending("/sound.caf")
                let soundFileURL = URL(fileURLWithPath: soundFilePath)
                // 녹음 품질 설정
                let recordSettings = [AVEncoderAudioQualityKey: AVAudioQuality.min.rawValue,
                                      AVEncoderBitRateKey: 16,
                                      AVNumberOfChannelsKey: 2,
                                      AVSampleRateKey: 44100.0] as [String : Any]
                
                // 공유 오디오 세션 인스턴스를 반환 받는다.
                let audioSession = AVAudioSession.sharedInstance()
                do {
                    // 현재 오디오 세션의 카테고리를 정한다. (재생, 녹음)
                    try audioSession.setCategory(AVAudioSession.Category.playAndRecord)
                } catch {
                    print("audioSession error: \(error.localizedDescription)")
        // Do any additional setup after loading the view.
                }
    
            
            // audioRecorder 인스턴스 생성
            do {
                try audioRecorder = AVAudioRecorder(url: soundFileURL, settings: recordSettings)
                audioRecorder?.prepareToRecord()
            } catch {
                print("audioSession Error: \(error.localizedDescription)")
            }
        }
    @IBAction func recordAudio(_ sender: UIButton) {
   
            if audioRecorder?.isRecording == false {
                playButton.isEnabled = false
                stopButton.isEnabled = true
                audioRecorder?.record()
            }
        }
        
    @IBAction func playAudio(_ sender: UIButton) {
    
            if audioRecorder?.isRecording == false {
                stopButton.isEnabled = true
                recordButton.isEnabled = false
                
                do {
                    try audioPlayer = AVAudioPlayer(contentsOf: audioRecorder!.url)
                    audioPlayer?.delegate = self
                    audioPlayer?.play()
                } catch {
                                print("audioPlayer error: \(error.localizedDescription)")
                            }
                        }
                    }
                    
    @IBAction func stopAudio(_ sender: UIButton) {

    
                        stopButton.isEnabled = false
                        playButton.isEnabled = true
                        recordButton.isEnabled = true
                        
                        if audioRecorder?.isRecording == true {
                            audioRecorder?.stop()
                        } else {
                            audioPlayer?.stop()
                        }
                    }
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
            recordButton.isEnabled = true
            stopButton.isEnabled = false
        }
        
        // 디코더 에러 발생하면 호출
        func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
            print("Audio Player Decode Error")
        }
        
        // MARK: - AVAudioRecorderDelegate
        
        // 시간 제한으로 녹음 종료하면 호출
        func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
            print("Record Success")
        }
    // 녹음중 에러 발생하면 호출
        func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
            print("Audio Record Encode Error")
        }
    @IBAction func save(_ sender: UIBarButtonItem) {
      
            let saveAlert = UIAlertController(title: "경고", message: "저장하시겠습니까?", preferredStyle: UIAlertController.Style.alert)
            let onAction = UIAlertAction(title: "네", style: UIAlertAction.Style.default, handler: nil)
            saveAlert.addAction(onAction)
            present(saveAlert, animated: true, completion: nil)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


